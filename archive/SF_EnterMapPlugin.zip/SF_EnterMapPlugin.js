/*:
 * @target MZ
 * @plugindesc マップに入った時だけ処理を実行する（グローバル版＋変数版）
 * @author sugarflower
 *
 * @help SF_EnterMapPlugin.js
 * 
 * イベント発生時に前回保存されたマップIDと現在のマップIDが同一だった場合処理を終了します。
 * ※このプラグイン以降に初期化の為の処理を書くことで違うマップが表示されたときに実行されます。
 *
 * @command enterMap
 * @text enterMap
 * @desc グローバル変数を使い、同じマップならコモンイベントを終了します。
 *
 * @command enterMapVar
 * @text enterMapVar
 * @desc 保存変数を使い、同じマップならコモンイベントを終了します。
 *
 * @arg savedVariable
 * @text 保存マップIDの変数
 * @type variable
 * @default 0
 */

(() => {

    'use strict';
    let _lastMapId = null;
    const pluginName = document.currentScript.src.split("/").pop().replace(/\.js$/, "");

    PluginManager.registerCommand(pluginName, "enterMap", function() {
        const currentMapId = $gameMap.mapId();
        if (_lastMapId === currentMapId) {
            this._index = this._list.length;
            return;
        }
        _lastMapId = currentMapId;
    });

    PluginManager.registerCommand(pluginName, "enterMapVar", function(args) {
        const savedVarId = Number(args.savedVariable);
        const savedMapId   = $gameVariables.value(savedVarId);
        const currentMapId = $gameMap.mapId();
        if (savedMapId === currentMapId) {
            this._index = this._list.length;
            return;
        }
        $gameVariables.setValue(savedVarId, currentMapId);
    });

})();
